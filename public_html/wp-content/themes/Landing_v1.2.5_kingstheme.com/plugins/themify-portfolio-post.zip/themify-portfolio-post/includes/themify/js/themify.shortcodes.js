(function($) {

	'use strict';

	$(window).load(function() {
		$('.shortcode.slider, .shortcode.post-slider').css({
			'height': 'auto',
			'visibility': 'visible'
		});
	});

})(jQuery);

